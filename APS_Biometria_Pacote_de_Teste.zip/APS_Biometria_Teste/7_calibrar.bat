@echo off
setlocal
cd /d "%~dp0codigo"
where python >nul 2>nul
if errorlevel 1 (
  echo Python nao encontrado. Instale o Python 3.12 marcando "Add python.exe to PATH" e tente de novo.
  pause
  exit /b 1
)
set PYTHONIOENCODING=utf-8
set COFRE_DADOS=%~dp0dados_teste
python -m cofre calibrar
echo.
pause
