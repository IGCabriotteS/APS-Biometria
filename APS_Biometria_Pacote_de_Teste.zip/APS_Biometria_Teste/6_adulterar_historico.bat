@echo off
setlocal
cd /d "%~dp0codigo"
where python >nul 2>nul
if errorlevel 1 (
  echo Python nao encontrado. Instale o Python 3.12 marcando "Add python.exe to PATH" e tente de novo.
  pause
  exit /b 1
)
set PYTHONIOENCODING=utf-8
set COFRE_DADOS=%~dp0dados_teste
echo Adulterando de proposito o historico da pasta dados_teste...
python ferramentas\adulterar_historico.py editar
echo Agora rode 5_cofre_roteiro.bat e escolha a opcao 6.
echo.
pause
